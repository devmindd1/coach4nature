module.exports = {
    host: "smtp-relay.brevo.com",
    port: 587,
    auth: {
        user: 'suzanne.holt.ballard@gmail.com',
        pass: 'kKLZpAznQa4I1hgS',
    },
    from: 'andris@kreata.ee',
    fromName: 'Andris'
};