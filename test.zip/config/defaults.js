module.exports = {
    _base_url: 'http://localhost:9025/',
    _base_url_api: 'http://localhost:9025/api/',
    userProfileImgPath: "/uploads/users/profile/",
    postImgPath: "/uploads/posts/",
    defaultStaticPath: 'public',
};