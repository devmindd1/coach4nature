const Model = require('../core/Model');

class CountryModel extends Model{
    constructor(){ super('countries'); }
}

module.exports = CountryModel;